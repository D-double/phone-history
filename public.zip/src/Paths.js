export const Paths = {
  phonehistory: '/phonehistory/',
  profile: '/user-2/:id',
  topuphistory: '/topuphistory/',
  editUzer: import.meta.env.VITE_BASE_URL + 'account-2/',  
}