import api from '../services/api';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'


// Асинхронное действие для получения данных о ценах для каждого id
export const loginUser = createAsyncThunk('user/loginUser',
  async (userData, {dispatch}) => {
    const results = await api.post(`/wp-json/jwt-auth/v1/token`, userData);
    const data = results.data
    dispatch(getProducts(data))
    // return data; // Возвращаем все результаты
  }
);
export const getProducts = createAsyncThunk('user/getProducts',
  async (data) => {
    localStorage.setItem('access_token', data.token)
    const results = await api.get(`/wp-json/wc/v3/products`);
    const list = results.data
    console.log(list);
    // return data; // Возвращаем все результаты
  }
);



const initialState = {
  api: 'JaBasLQyxRLgv3h0RnXMLCZAXaShlynz',
  domen: 'gmail.com',
  userData: null
};

// Создание слайса
export const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
  },
  extraReducers: (builder) => {
    builder.addCase(loginUser.pending, (state) => {
      state.userData = null;
    });
    builder.addCase(loginUser.fulfilled, (state, action) => {
        const data = action.payload;
        if (data && data.token) {
          state.userData = data; // Сохраняем результаты 
          localStorage.setItem('access_token', data.token)
        }
    });
  }
});

// export const { } = userSlice.actions

export default userSlice.reducer;