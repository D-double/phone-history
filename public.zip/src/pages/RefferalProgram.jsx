import React from 'react'

const RefferalProgram = () => {
  return (
    <div>RefferalProgram</div>
  )
}

export default RefferalProgram