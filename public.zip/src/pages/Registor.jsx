import React from 'react'

const Registor = () => {
  return (
    <div>
      <h1>fddsfds
        
      </h1>
    </div>
  )
}

export default Registor