import React from 'react'
import './PaidOnly.scss'

function PaidOnly() {
  return (
    <div>PaidOnly</div>
  )
}

export default PaidOnly