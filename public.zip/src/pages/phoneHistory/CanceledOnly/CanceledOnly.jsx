import React from 'react'
import './CanceledOnly.scss'

const CanceledOnly = () => {
  return (
    <div>CanceledOnly</div>
  )
}

export default CanceledOnly