import React from 'react'
import './WaitingForCode.scss'

const WaitingForCode = () => {
  return (
    <div>WaitingForCode</div>
  )
}

export default WaitingForCode