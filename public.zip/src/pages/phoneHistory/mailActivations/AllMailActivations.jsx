import React from 'react'
import './AllMailActivations.scss'

const AllMailActivations = () => {
  return (
    <div>AllMailActivations</div>
  )
}

export default AllMailActivations