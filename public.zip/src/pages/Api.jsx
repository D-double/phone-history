import React from 'react'

const Api = () => {
  return (
    <div>api</div>
  )
}

export default Api