import React from 'react'

const SmsActive = () => {
  return (
    <div>SmsActive</div>
  )
}

export default SmsActive