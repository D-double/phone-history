import React from 'react'

const TemporaryMail = () => {
  return (
    <div>TemporaryMail</div>
  )
}

export default TemporaryMail